
(function() {
	var _timer   = null;
	var _current = '';
	var _kid     = parseInt(document.getElementById('sr-kingdom-id').value) || 0;
	var _pid     = parseInt(document.getElementById('sr-park-id').value)    || 0;

	function renderResults(data) {
		var tbody  = document.getElementById('sr-tbody');
		var countEl = document.getElementById('sr-count');

		if (!data || data.length === 0) {
			tbody.innerHTML = '<tr><td colspan="3" class="sr-empty">'
				+ '<i class="fas fa-user-slash"></i>No players found.</td></tr>';
			countEl.style.display = 'none';
			return;
		}

		// Sort: active first, then inactive, banned last
		data.sort(function(a, b) {
			var aBanned = a.Suspended == 1 ? 1 : 0;
			var bBanned = b.Suspended == 1 ? 1 : 0;
			if (aBanned !== bBanned) return aBanned - bBanned;
			if (b.Active !== a.Active) return b.Active - a.Active;
			var pa = (a.Persona || '').toLowerCase();
			var pb = (b.Persona || '').toLowerCase();
			return pa < pb ? -1 : pa > pb ? 1 : 0;
		});

		var html = '';
		for (var i = 0; i < data.length; i++) {
			var v       = data[i];
			var active  = v.Active !== 0;
			var banned  = v.Suspended == 1;
			var rowCls  = banned ? ' sr-row-banned' : (active ? '' : ' sr-row-inactive');
			var kingdom = v.KingdomName || '';
			var park    = v.ParkName    || '';
			var persona = v.Persona     || v.UserName || '';
			var badge   = banned ? '<span class="sr-badge-banned">Banned</span>'
			            : (active ? '' : '<span class="sr-badge-inactive">Inactive</span>');
			var url     = 'http://127.0.0.1:19080/orkui/index.php?Route=Player/profile/' + v.MundaneId;

			html += '<tr class="sr-row' + rowCls + '" onclick="window.location.href=\'' + url + '\'">'
				+ '<td>' + kingdom + '</td>'
				+ '<td>' + park + '</td>'
				+ '<td><span class="sr-player-name">' + persona + '</span>' + badge + '</td>'
				+ '</tr>';
		}

		if (data.length >= 100) {
			html += '<tr><td colspan="3" class="sr-overflow-warning">'
				+ '<i class="fas fa-exclamation-triangle"></i>'
				+ '&ensp;Showing the first 100 results &mdash; please refine your search if you don\'t see who you\'re looking for.'
				+ '</td></tr>';
		}
		tbody.innerHTML = html;
		countEl.textContent = data.length >= 100 ? '100+ results' : data.length + ' result' + (data.length === 1 ? '' : 's');
		countEl.style.display = '';
	}

	function doSearch(term) {
		var params = {
			Action:  'Search/Player',
			search:  term.trim(),
			type:    'all',
			limit:   100,
			token:   ''
		};
		if (_kid > 0) params.kingdom_id = _kid;
		if (_pid > 0) params.park_id    = _pid;

		$.getJSON('http://127.0.0.1:19080/orkservice/Search/SearchService.php', params, function(data) {
			if (term === _current) renderResults(data);
		});
	}

	document.getElementById('sr-player-input').addEventListener('input', function() {
		var term = this.value;
		_current = term;
		clearTimeout(_timer);
		if (term.length < 2) {
			document.getElementById('sr-tbody').innerHTML =
				'<tr><td colspan="3" class="sr-empty"><i class="fas fa-search"></i>Enter a name above to search for players.</td></tr>';
			document.getElementById('sr-count').style.display = 'none';
			return;
		}
		_timer = setTimeout(function() { doSearch(term); }, 300);
	});
})();
