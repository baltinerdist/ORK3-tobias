
(function () {
	if (!$('#od-table').length) return;

	var odSkipWords = /^(the|kingdom|empire|freehold|principality|of)\s+/i;
	function odSortKey(name) {
		var s = name.trim(), prev;
		do { prev = s; s = s.replace(odSkipWords, ''); } while (s !== prev);
		return s.toLowerCase();
	}

	var table = $('#od-table').DataTable({
		dom        : 'lfrtip',
		pageLength : 50,
		scrollX    : true,
		order      : [[0, 'asc']],
		fixedHeader: { headerOffset: 48 },
		columnDefs : [
			{
				targets: 0,
				render: function (data, type) {
					if (type === 'sort' || type === 'filter') {
						var tmp = document.createElement('div');
						tmp.innerHTML = data;
						return odSortKey(tmp.textContent || tmp.innerText || '');
					}
					return data;
				}
			},
			{ targets: [1, 2, 3, 4, 5], orderable: false }
		]
	});

	/* CSV export — strips HTML from cells */
	$('#od-btn-csv').on('click', function () {
		var headers = [];
		$('#od-table thead th').each(function () { headers.push($(this).text().trim()); });
		var rows = [headers.join(',')];
		table.rows({ search: 'applied' }).every(function () {
			var cells = [];
			$(this.node()).find('td').each(function () {
				var text = $(this).text().trim().replace(/"/g, '""');
				cells.push('"' + text + '"');
			});
			rows.push(cells.join(','));
		});
		var blob = new Blob([rows.join('\n')], { type: 'text/csv' });
		var a    = document.createElement('a');
		a.href   = URL.createObjectURL(blob);
		a.download = 'officer-directory.csv';
		a.click();
	});
}());
