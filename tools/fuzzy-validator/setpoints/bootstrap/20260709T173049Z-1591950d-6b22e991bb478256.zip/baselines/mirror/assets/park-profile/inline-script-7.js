
window.OrkRsCfg = {
	uir:         'http://127.0.0.1:19080/orkui/index.php?Route=',
	userId:      1,
	userPersona: "",
	reload:      function() { location.reload(); }
};
